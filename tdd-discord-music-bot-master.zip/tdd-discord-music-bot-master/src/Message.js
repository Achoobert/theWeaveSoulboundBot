export default class Message {
  constructor(chatRoom, content){
    this.chatRoom = chatRoom;
    this.content = content;
  }
}